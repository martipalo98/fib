#define GAME_NAME "ThePurge"
#define VERSION   "1.0"
